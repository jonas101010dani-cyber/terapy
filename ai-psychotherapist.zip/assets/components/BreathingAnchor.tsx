import { useState, useEffect } from "react";
import { Wind, Play, Pause, RefreshCw } from "lucide-react";

export default function BreathingAnchor() {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<"inhale" | "hold" | "exhale" | "rest">("inhale");
  const [secondsLeft, setSecondsLeft] = useState(4);

  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;

    if (isActive) {
      timer = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            // Transition to the next phase in the 4-4-4-4 box breathing cycle
            setPhase((currentPhase) => {
              switch (currentPhase) {
                case "inhale":
                  setSecondsLeft(4);
                  return "hold";
                case "hold":
                  setSecondsLeft(4);
                  return "exhale";
                case "exhale":
                  setSecondsLeft(4);
                  return "rest";
                case "rest":
                  setSecondsLeft(4);
                  return "inhale";
                default:
                  setSecondsLeft(4);
                  return "inhale";
              }
            });
            return 4;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setSecondsLeft(4);
      setPhase("inhale");
    }

    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isActive]);

  const getPhaseText = () => {
    switch (phase) {
      case "inhale":
        return "Breathe In...";
      case "hold":
        return "Hold...";
      case "exhale":
        return "Breathe Out...";
      case "rest":
        return "Rest & Be Still...";
    }
  };

  const getPhaseStyles = () => {
    switch (phase) {
      case "inhale":
        return {
          scale: "scale-125",
          color: "bg-emerald-50 text-emerald-700 border-emerald-300 ring-emerald-100",
          desc: "Expand your chest and fill with warmth.",
        };
      case "hold":
        return {
          scale: "scale-125 opacity-90",
          color: "bg-amber-50 text-amber-700 border-amber-300 ring-amber-100",
          desc: "Settle into the quiet stillness.",
        };
      case "exhale":
        return {
          scale: "scale-90",
          color: "bg-sky-50 text-sky-700 border-sky-300 ring-sky-100",
          desc: "Release tension and soften your shoulders.",
        };
      case "rest":
        return {
          scale: "scale-95 opacity-80",
          color: "bg-slate-50 text-slate-700 border-slate-350 ring-slate-100",
          desc: "Acknowledge the physical space around you.",
        };
    }
  };

  const style = getPhaseStyles();

  return (
    <div className="bg-stone-50 border border-stone-250/60 rounded-2xl p-5 mb-6 fade-in shadow-xs">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2 text-stone-700">
          <Wind className="w-5 h-5 text-emerald-600" />
          <h3 className="font-serif text-lg font-medium text-stone-800">Mindfulness Breathing Space</h3>
        </div>
        <p className="text-xs text-stone-500 font-mono">Box Technique (4s-4s-4s-4s)</p>
      </div>

      <div className="flex flex-col md:flex-row items-center gap-6 justify-around">
        {/* Animated breathing circle container */}
        <div className="relative w-40 h-40 flex items-center justify-center">
          {/* Ripple rings */}
          {isActive && (
            <>
              <div
                className={`absolute inset-0 rounded-full border border-emerald-200/50 ring-8 ring-emerald-50/10 transition-all duration-[4000ms] ease-in-out ${
                  phase === "inhale" ? "scale-150 opacity-100" : "scale-100 opacity-0"
                }`}
              />
              <div
                className={`absolute inset-0 rounded-full border border-sky-200/50 ring-8 ring-sky-50/10 transition-all duration-[4000ms] ease-in-out ${
                  phase === "exhale" ? "scale-75 opacity-100" : "scale-100 opacity-0"
                }`}
              />
            </>
          )}

          {/* Central Breath Ball */}
          <div
            className={`w-32 h-32 rounded-full border-2 border-dashed flex flex-col items-center justify-center transition-all duration-[4000ms] ease-in-out shadow-xs ring-12 ${style.color} ${
              isActive ? style.scale : "scale-100 bg-stone-100 border-stone-300 text-stone-500"
            }`}
          >
            <span className="font-serif font-semibold text-sm transition-opacity duration-300">
              {isActive ? getPhaseText() : "Ready?"}
            </span>
            <span className="text-2xl font-mono font-bold mt-1">
              {isActive ? secondsLeft : "•"}
            </span>
          </div>
        </div>

        {/* Breathing description and controls */}
        <div className="flex-1 text-center md:text-left">
          <p className="text-stone-700 font-serif italic text-sm min-h-[40px] leading-relaxed">
            {isActive ? style.desc : "Ground yourself in the present moment. Click 'Begin Breathing' to initialize a guided equal-expansion cycle."}
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-4 justify-center md:justify-start">
            <button
              onClick={() => setIsActive(!isActive)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold tracking-wide transition shadow-xs cursor-pointer ${
                isActive
                  ? "bg-stone-200 hover:bg-stone-300 text-stone-800"
                  : "bg-emerald-700 hover:bg-emerald-800 text-stone-50"
              }`}
            >
              {isActive ? (
                <>
                  <Pause className="w-3.5 h-3.5" /> Pause Pacer
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5" /> Begin Breathing
                </>
              )}
            </button>

            {isActive && (
              <button
                onClick={() => {
                  setPhase("inhale");
                  setSecondsLeft(4);
                }}
                className="flex items-center gap-1 px-3 py-2 rounded-xl border border-stone-250 bg-white hover:bg-stone-50 text-xs text-stone-600 transition shadow-2xs cursor-pointer"
                title="Restart Cycle"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Sync Cycle
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
