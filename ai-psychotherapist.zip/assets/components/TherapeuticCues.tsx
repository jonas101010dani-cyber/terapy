import { BrainCircuit, Compass, Target, HelpCircle } from "lucide-react";
import { TherapeuticFocus } from "../types";

const RECOMMENDATIONS: TherapeuticFocus[] = [
  {
    theme: "Self-Criticism",
    label: "CBT Reframe Exercise",
    prompt: "I want to examine an unkind, harsh self-critical thought and work on identifying any cognitive distortions I might be falling into.",
  },
  {
    theme: "Values",
    label: "ACT Values Clarification",
    prompt: "Help me explore what truly matters to me at this point in my life, and identify a micro-commitment or small action I can take.",
  },
  {
    theme: "Mindfulness",
    label: "Sensory Grounding (5-4-3-2-1)",
    prompt: "I am feeling extremely anxious or disconnected. Could you guide me through a 5-4-3-2-1 grounding exercise to calm my nervous system?",
  },
  {
    theme: "Anxiety",
    label: "Compassionate Venting Space",
    prompt: "I had an extremely exhausting and difficult day. I just need a safe, private space to vent my thoughts without pressure.",
  },
];

interface TherapeuticCuesProps {
  onSelectCue: (prompt: string) => void;
}

export default function TherapeuticCues({ onSelectCue }: TherapeuticCuesProps) {
  const getThemeIcon = (theme: string) => {
    switch (theme) {
      case "Self-Criticism":
        return <BrainCircuit className="w-4 h-4 text-emerald-600" />;
      case "Values":
        return <Target className="w-4 h-4 text-purple-600" />;
      case "Mindfulness":
        return <Compass className="w-4 h-4 text-sky-650" />;
      default:
        return <HelpCircle className="w-4 h-4 text-stone-600" />;
    }
  };

  const getThemeBg = (theme: string) => {
    switch (theme) {
      case "Self-Criticism":
        return "hover:border-emerald-300 hover:bg-emerald-50/40 border-stone-250";
      case "Values":
        return "hover:border-purple-300 hover:bg-purple-50/40 border-stone-250";
      case "Mindfulness":
        return "hover:border-sky-300 hover:bg-sky-50/40 border-stone-250";
      default:
        return "hover:border-stone-400 hover:bg-stone-50 border-stone-250";
    }
  };

  return (
    <div className="mb-6">
      <p className="text-xs font-semibold text-stone-500 uppercase tracking-wider mb-2.5">
        Recommended Reflective Prompts
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {RECOMMENDATIONS.map((rec) => (
          <button
            key={rec.label}
            onClick={() => onSelectCue(rec.prompt)}
            className={`flex items-center gap-2.5 p-3.5 text-left bg-white border rounded-xl text-xs transition duration-250 shadow-2xs group cursor-pointer ${getThemeBg(
              rec.theme
            )}`}
          >
            <div className={`p-1.5 rounded-lg bg-stone-100 group-hover:bg-white transition`}>
              {getThemeIcon(rec.theme)}
            </div>
            <div className="flex-1 min-w-0">
              <span className="font-serif font-medium text-stone-800 text-[13px] block mb-0.5 truncate">
                {rec.label}
              </span>
              <span className="text-stone-500 text-[11px] block truncate leading-normal">
                {rec.prompt}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
