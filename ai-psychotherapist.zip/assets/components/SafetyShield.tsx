import { ShieldAlert, Heart, Phone, Sparkles } from "lucide-react";

interface SafetyShieldProps {
  onDismiss?: () => void;
  isTriggeredAutomatically?: boolean;
}

export default function SafetyShield({ onDismiss, isTriggeredAutomatically = false }: SafetyShieldProps) {
  return (
    <div className={`p-5 rounded-2xl border ${
      isTriggeredAutomatically 
        ? "bg-rose-50 border-rose-300 ring-4 ring-rose-100" 
        : "bg-stone-50 border-stone-250"
    } duration-300 ease-in-out fade-in mb-6 shadow-xs`}>
      <div className="flex items-start gap-4">
        <div className={`p-2.5 rounded-xl ${isTriggeredAutomatically ? "bg-rose-100 text-rose-700" : "bg-stone-200/65 text-stone-700"}`}>
          <ShieldAlert className="w-5.5 h-5.5" />
        </div>

        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className={`text-xs font-bold tracking-wider uppercase px-2 py-0.5 rounded-md ${
              isTriggeredAutomatically ? "bg-rose-100 text-rose-800" : "bg-stone-200 text-stone-700"
            }`}>
              Immediate Support Banner
            </span>
            <span className="flex items-center gap-1 text-xs text-stone-500 font-medium">
              <Heart className="w-3 h-3 text-rose-400 fill-rose-400" /> Free & Confidential
            </span>
          </div>

          <h3 className="font-serif text-lg font-medium text-stone-900 mt-1.5 leading-snug">
            Your safety and well-being are paramount
          </h3>

          <p className="text-stone-700 text-sm mt-2 leading-relaxed">
            {isTriggeredAutomatically 
              ? "We sensed some thoughts or patterns that indicate you might be going through a deeply heavy or critical moment of distress. We are here with you, but as an AI companion, we cannot replace human professional care. We gently and strongly urge you to reach out to a trained crisis counselor immediately."
              : "During heavy or overwhelming times of challenge, please remember you don't have to carry this alone. Support is available to you around the clock, free and completely private."
            }
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
            <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-center gap-3">
              <div className="p-2 bg-emerald-50 rounded-lg text-emerald-800 font-bold text-sm tracking-wide flex items-center justify-center min-w-10">
                988
              </div>
              <div>
                <h4 className="text-xs font-semibold text-stone-800">Lifeline (US & Canada)</h4>
                <p className="text-[11px] text-stone-500">Call or Text. Toll-free 24/7</p>
              </div>
            </div>

            <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-center gap-3">
              <div className="p-2 bg-sky-50 rounded-lg text-sky-850 font-bold text-xs tracking-wide flex items-center justify-center min-w-10">
                HOME
              </div>
              <div>
                <h4 className="text-xs font-semibold text-stone-800">Crisis Text Line (US / UK)</h4>
                <p className="text-[11px] text-stone-500">Text HOME to 741741</p>
              </div>
            </div>

            <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-center gap-3">
              <div className="p-1.5 bg-indigo-50 rounded-lg text-indigo-800 flex items-center justify-center min-w-10">
                <Phone className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-semibold text-stone-800">International Directory</h4>
                <a 
                  href="https://www.befrienders.org/" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="text-[11px] text-indigo-650 hover:underline inline-flex items-center gap-0.5"
                >
                  befrienders.org <Sparkles className="w-2.5 h-2.5 text-indigo-400" />
                </a>
              </div>
            </div>

            <div className="p-3 bg-white border border-stone-200 rounded-xl flex items-center gap-3">
              <div className="p-2 bg-stone-100 rounded-lg text-stone-800 font-bold text-xs tracking-wide flex items-center justify-center min-w-10">
                111
              </div>
              <div>
                <h4 className="text-xs font-semibold text-stone-800">NHS Services (UK)</h4>
                <p className="text-[11px] text-stone-500">Call 111 (or Samaritans 116 123)</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 mt-4">
            <a 
              href="https://findahelpline.com/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="px-3.5 py-1.5 bg-stone-700 hover:bg-stone-800 text-stone-50 rounded-xl text-xs font-medium cursor-pointer transition shadow-2xs"
            >
              Find Local Helpline (Worldwide)
            </a>
            {onDismiss && (
              <button 
                onClick={onDismiss}
                className="text-stone-500 hover:text-stone-700 text-xs font-medium cursor-pointer"
              >
                Close Banner
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
