/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { 
  Send, 
  Heart, 
  Sparkles, 
  ShieldAlert, 
  Eraser, 
  Compass, 
  BrainCircuit, 
  Info, 
  MessageSquare,
  Lock,
  ArrowDownCircle,
  HelpCircle
} from "lucide-react";
import { Message } from "./types";
import BreathingAnchor from "./components/BreathingAnchor";
import SafetyShield from "./components/SafetyShield";
import TherapeuticCues from "./components/TherapeuticCues";

const WELCOME_MESSAGE: Message = {
  id: "welcome-system",
  role: "assistant",
  content: "Hello, and thank you for taking a moment matching this space. I am your gentle AI reflection companion, modeled with deep principles of humanistic support, active listening, and open introspective inquiries. \n\nThis is a private, non-judgmental harbor for your thoughts, struggles, or mindfulness practice. You are safe to share your vulnerabilities, parse daily exhaustion, or practice grounding. \n\nHow is your heart holding up, and what is weighing most on you in this moment?",
  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
};

export default function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showSafetyBanner, setShowSafetyBanner] = useState(false);
  const [crisisAlertTriggered, setCrisisAlertTriggered] = useState(false);
  const [isCopied, setIsCopied] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize messages from LocalStorage, keeping session safe and local
  useEffect(() => {
    const saved = localStorage.getItem("therapist_sessions");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.length > 0) {
          setMessages(parsed);
          // Check if any existing message in history has crisis themes to preserve safety
          const combinedText = parsed.map((m: Message) => m.content.toLowerCase()).join(" ");
          detectCrisisPotential(combinedText);
        } else {
          setMessages([WELCOME_MESSAGE]);
        }
      } catch (e) {
        setMessages([WELCOME_MESSAGE]);
      }
    } else {
      setMessages([WELCOME_MESSAGE]);
    }
  }, []);

  // Save current thread locally
  const saveToLocal = (updatedList: Message[]) => {
    localStorage.setItem("therapist_sessions", JSON.stringify(updatedList));
  };

  // Scroll to bottom on updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  // Detect words suggesting self-harm, emotional threat, or crisis
  const detectCrisisPotential = (text: string) => {
    const crisisTokens = [
      "suicide", "suicidal", "kill myself", "end my life", "want to die", 
      "self-harm", "self harm", "hurt myself", "cutting myself", "overdose", 
      "hanging myself", "die today", "slit my", "better off dead"
    ];
    const match = crisisTokens.some(token => text.toLowerCase().includes(token));
    if (match) {
      setCrisisAlertTriggered(true);
      setShowSafetyBanner(true);
    }
  };

  // Handle submitting interaction
  const handleSend = async (textToSend?: string) => {
    const rawText = textToSend || input;
    const finalMessageStr = rawText.trim();
    if (!finalMessageStr) return;

    if (!textToSend) setInput("");

    // Detect crisis indicators
    detectCrisisPotential(finalMessageStr);

    const userMsg: Message = {
      id: `m-user-${Date.now()}`,
      role: "user",
      content: finalMessageStr,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    saveToLocal(nextMessages);
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: nextMessages }),
      });

      if (!response.ok) {
        throw new Error("Unable to establish proper therapeutic proxy. Server error.");
      }

      const data = await response.json();
      
      const assistantMsg: Message = {
        id: `m-ai-${Date.now()}`,
        role: "assistant",
        content: data.content,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      const finalMessages = [...nextMessages, assistantMsg];
      setMessages(finalMessages);
      saveToLocal(finalMessages);
    } catch (err: any) {
      console.error(err);
      const errMessage: Message = {
        id: `m-err-${Date.now()}`,
        role: "assistant",
        content: "I encountered a minor lapse in communication. Please rest assured I am here. Sometimes, these secure tunnels can stall. Could you click the recycle button to retrace, or perhaps share your thought once more?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages([...nextMessages, errMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // Clear Session History & erase private client data
  const handleClearHistory = () => {
    if (window.confirm("Are you absolutely sure you want to completely erase your private reflection chat history? This cannot be undone.")) {
      setMessages([WELCOME_MESSAGE]);
      saveToLocal([]);
      setCrisisAlertTriggered(false);
      setShowSafetyBanner(false);
    }
  };

  // Trigger rapid text selection from cue recommendations
  const handleCueSelect = (prompt: string) => {
    setInput("");
    handleSend(prompt);
  };

  const copyRefinement = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(id);
    setTimeout(() => setIsCopied(null), 2000);
  };

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col font-sans antialiased text-stone-800">
      {/* Upper Subtle Identity Header */}
      <header id="app-header" className="bg-white/80 backdrop-blur-md border-b border-stone-200/80 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-3 sm:py-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-100 text-emerald-850">
              <Compass className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-serif text-lg sm:text-xl font-bold tracking-tight text-stone-900">
                  AI Psychotherapist
                </h1>
                <span className="text-[10px] font-mono font-medium bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded border border-emerald-100">
                  Companion Edition
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-stone-500 leading-tight">
                Empathetic guidance, CBT/ACT frameworks, & mindful breathing space
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => setShowSafetyBanner(!showSafetyBanner)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium cursor-pointer transition ${
                showSafetyBanner 
                  ? "bg-rose-100 text-rose-800 border border-rose-200" 
                  : "bg-stone-100 hover:bg-stone-200 text-stone-700 border border-transparent"
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
              <span>Safety & Crisis Contacts</span>
            </button>

            <button
              onClick={handleClearHistory}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-stone-500 hover:text-stone-800 hover:bg-stone-100 border border-transparent cursor-pointer transition"
              title="Completely erase your localized browser cookie chat data."
            >
              <Eraser className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Erase Session</span>
            </button>
            
            <div className="flex items-center gap-1.5 text-[10px] text-stone-500 uppercase tracking-widest bg-stone-50 border border-stone-200 px-2.5 py-1.5 rounded-xl font-mono">
              <Lock className="w-3 h-3 text-emerald-600" />
              <span>Transient Log</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Multi-Grid Body */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6 flex flex-col lg:grid lg:grid-cols-12 gap-6 min-h-[calc(100vh-140px)]">
        
        {/* Left Side Panel - Exercises, instructions, medical disclaimer */}
        <section id="sidebar-panel" className="lg:col-span-4 flex flex-col gap-6">
          
          {/* Dynamic Breathing Space (Always active for calming anxiety) */}
          <BreathingAnchor />

          {/* Quick Informative Clinical Note */}
          <div className="bg-white border border-stone-200/80 rounded-2xl p-5 shadow-2xs">
            <div className="flex gap-2.5 items-start">
              <Info className="w-4.5 h-4.5 text-stone-600 mt-0.5 shrink-0" />
              <div>
                <h3 className="font-serif text-[15px] font-medium text-stone-900">
                  How This Experience Works
                </h3>
                <p className="text-xs text-stone-600 mt-2 leading-relaxed">
                  We leverage principles from <strong>Cognitive Behavioral Therapy (CBT)</strong>, 
                  <strong> Acceptance &amp; Commitment Therapy (ACT)</strong>, and centered 
                  mindfulness exercises.
                </p>
                
                <ul className="text-xs text-stone-500 space-y-2 mt-3 list-none">
                  <li className="flex items-start gap-1.5">
                    <span className="text-emerald-650 font-bold">•</span>
                    <span><strong>Validation First:</strong> Expect active emotional acknowledgment of your unique state.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-indigo-600 font-bold">•</span>
                    <span><strong>Deep Reflections:</strong> Endings usually have open prompts. Share without hurry or judgment.</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-purple-600 font-bold">•</span>
                    <span><strong>Private Buffer:</strong> All content is securely held locally on your local device.</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="border-t border-stone-100 mt-4 pt-3 text-[11px] text-stone-600 italic leading-relaxed">
              <strong>Support Information Disclaimer:</strong> This artificial companion serves cognitive self-reflection support. It cannot diagnose, prescribe medication, or act as a substitute for real biological clinical care.
            </div>
          </div>

          <div className="text-center py-2 text-[11px] text-stone-500 flex items-center justify-center gap-1">
            <span>Made with deep care &amp; empathy</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500 animate-pulse" />
          </div>
        </section>

        {/* Right Side Panel - The Compassionate Chat Thread */}
        <section id="chat-panel" className="lg:col-span-8 flex flex-col bg-white border border-stone-200/80 rounded-3xl overflow-hidden shadow-xs relative min-h-[500px]">
          
          {/* Active Safety Support Banner */}
          {showSafetyBanner && (
            <div className="border-b border-rose-100 bg-rose-50/70 p-1">
              <SafetyShield 
                isTriggeredAutomatically={crisisAlertTriggered} 
                onDismiss={() => {
                  setShowSafetyBanner(false);
                  setCrisisAlertTriggered(false);
                }} 
              />
            </div>
          )}

          {/* Interactive Cue Suggestions (At the top of the chat area to serve as rapid reflection entry points) */}
          <div className="p-4 bg-stone-50 border-b border-stone-100">
            <TherapeuticCues onSelectCue={handleCueSelect} />
          </div>

          {/* Chat Messages Log */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 dialog-scrollbar max-h-[500px]">
            {messages.map((msg, index) => {
              const isAi = msg.role === "assistant";
              return (
                <div 
                  key={msg.id || index}
                  className={`flex flex-col ${isAi ? "items-start" : "items-end"} fade-in`}
                >
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-[10px] text-stone-500 tracking-wide font-mono uppercase">
                      {isAi ? "Wellness Companion" : "Your thoughts"}
                    </span>
                    <span className="text-[10px] text-stone-400 font-mono">
                      {msg.timestamp || "10:00"}
                    </span>
                  </div>

                  <div className="flex items-start gap-2.5 max-w-[92%] sm:max-w-[85%]">
                    {isAi && (
                      <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-800 flex items-center justify-center text-xs border border-emerald-100/60 shrink-0 mt-0.5">
                        <Heart className="w-3.5 h-3.5 fill-emerald-100 text-emerald-700" />
                      </div>
                    )}
                    
                    <div className={`p-4 rounded-2xl relative group ${
                      isAi 
                        ? "bg-lightcream border border-stone-150 text-stone-800 font-serif leading-relaxed text-[14.5px] whitespace-pre-wrap selection:bg-emerald-100" 
                        : "bg-stone-700 text-stone-105 sans-serif text-sm px-4.5 py-3 whitespace-pre-wrap select-text selection:bg-stone-500"
                    }`}>
                      {msg.content}

                      {/* Small Quick Utilities for AI answers */}
                      {isAi && (
                        <div className="opacity-0 group-hover:opacity-100 transition duration-200 mt-2 flex items-center justify-end gap-2 text-[10px] text-stone-500">
                          <button
                            onClick={() => copyRefinement(msg.content, msg.id)}
                            className="hover:text-stone-850 px-2 py-0.5 rounded bg-stone-100/85 hover:bg-stone-200/85 cursor-pointer text-[10px] transition"
                          >
                            {isCopied === msg.id ? "✓ Copied Reflection" : "Copy text"}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {/* Simulated Loading/Thinking state */}
            {isLoading && (
              <div className="flex items-start gap-2.5 max-w-[85%] fade-in">
                <div className="w-7 h-7 rounded-lg bg-stone-100 text-stone-750 flex items-center justify-center shrink-0 mt-1 animate-pulse">
                  <Compass className="w-3.5 h-3.5 animate-spin duration-[4000ms]" />
                </div>
                <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4">
                  <div className="flex items-center gap-1.5 mb-2">
                    <span className="text-[10px] text-stone-550/80 font-mono uppercase tracking-wider animate-pulse">
                      Active Listening...
                    </span>
                  </div>
                  <p className="text-xs text-stone-600 font-serif italic mb-2">
                    "I am reflecting deeply on your words to offer a safe, grounding response..."
                  </p>
                  <div className="flex gap-1.5 items-center justify-start py-0.5">
                    <div className="w-2 h-2 rounded-full bg-stone-400 animate-bounce delay-100" />
                    <div className="w-2 h-2 rounded-full bg-stone-400 animate-bounce delay-200" />
                    <div className="w-2 h-2 rounded-full bg-stone-400 animate-bounce delay-300" />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Message Input Controls Panel */}
          <div className="p-4 sm:p-5 bg-stone-50/80 backdrop-blur-md border-t border-stone-200/80">
            <div className="flex gap-3">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="Share whatever is nested in your heart... (Press Enter or click send)"
                className="flex-1 bg-white border border-stone-250/70 rounded-xl px-4 py-3 text-sm text-stone-850 placeholder-stone-500/80 focus:outline-hidden focus:ring-2 focus:ring-stone-600/30 font-sans shadow-2xs"
                disabled={isLoading}
              />
              <button
                onClick={() => handleSend()}
                disabled={isLoading || !input.trim()}
                className={`p-3 rounded-xl flex items-center justify-center transition shadow-2xs cursor-pointer ${
                  isLoading || !input.trim()
                    ? "bg-stone-200 text-stone-400"
                    : "bg-stone-850 hover:bg-stone-900 text-white"
                }`}
                title="Send reflection details"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
            
            <div className="mt-2.5 flex items-center justify-between text-[11px] text-stone-500">
              <span className="flex items-center gap-1">
                <Lock className="w-3 h-3 text-emerald-800" /> All logs remain private &amp; localized.
              </span>
              <span>
                CBT, ACT &amp; Mindfulness support
              </span>
            </div>
          </div>

        </section>

      </main>

      {/* Grounded Page Footer */}
      <footer className="bg-stone-100 border-t border-stone-200 py-6 mt-auto">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-xs text-stone-500 leading-relaxed font-serif italic">
            "We accept that discomfort is normal, and we navigate the pathways of life with step-by-step kindness."
          </p>
          <p className="text-[11px] text-stone-500 mt-2 font-mono">
            AI Psychotherapist © 2026. Private Sandbox Container.
          </p>
        </div>
      </footer>
    </div>
  );
}
