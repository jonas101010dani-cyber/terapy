export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export type FocusTheme = "Anxiety" | "Self-Criticism" | "Values" | "Mindfulness" | "General";

export interface TherapeuticFocus {
  label: string;
  prompt: string;
  theme: FocusTheme;
}
